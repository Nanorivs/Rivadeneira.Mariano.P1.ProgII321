package paquete;

public class Robot extends UnidadOperativa implements Desplazable{
    private double autonomiaOperativa;

    public Robot(String ID, String modulo, TipoAtmosfera atmosfera,double autonomiaOperativa) {
        super(ID, modulo, atmosfera);
        this.autonomiaOperativa = autonomiaOperativa;
    }

    @Override
    public void reabastecerse() {
            System.out.println( getClassName() + " se reabastecio y ahora funciona con energia" );
    }

    @Override
    public void mantenerCondicionesAtmosfericas() {
        System.out.println(getClassName() + " mantiene las condiciones atmosfericas justas para sus circuitos");
    }

    @Override
    public void replicarse() {
        System.out.println(getClassName() + " se ha replicado exitosamente");
    }

    @Override
    public void moverUnidad() {
        System.out.println("Este magnifico "+ getClassName() + " se traslado rigidamente");
    }
    @Override 
    public String toString(){   
        return super.toString() + "Autonomia operativa: " + autonomiaOperativa + "\n" ;
        
    }

}
