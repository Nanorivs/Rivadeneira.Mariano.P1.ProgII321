
package paquete;

public class IdRepetidoException extends Exception {
    private static final String MESSAGE = "Id repetido";
    
    public  IdRepetidoException(){
        this(MESSAGE);
    }
     public  IdRepetidoException(String message){
        super(message);
}
}

