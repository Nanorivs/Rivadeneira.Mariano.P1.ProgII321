package paquete;

public class Astronauta extends UnidadOperativa implements Desplazable{
    private double eva ;

    public Astronauta(String ID, String modulo, TipoAtmosfera atmosfera, double eva) {
        super(ID, modulo, atmosfera);
        this.eva = eva;
    }

    @Override
    public void reabastecerse() {
        System.out.println(getClassName() + " se reabastecio y se siente bien");
    }

    @Override
    public void mantenerCondicionesAtmosfericas() {
        System.out.println("Las condiciones atmosfericas del " + getClassName() + " fueron restauradas");
    }

    @Override
    public void replicarse() {
        System.out.println("Se ha replicado exitosamente al " + getClassName() );
    }

    @Override
    public void moverUnidad() {
        System.out.println(getClassName() + " ha caminado y se siente revitalizado");
    }
    @Override 
    public String toString(){   
        return super.toString() + "EVA: " + eva ;
        
    }


    
}
