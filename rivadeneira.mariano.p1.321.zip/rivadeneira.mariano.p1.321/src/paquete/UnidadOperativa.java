package paquete;

import java.util.Objects;

public abstract class UnidadOperativa {
    private final String ID;
    private String modulo;
    private TipoAtmosfera atmosfera;
    
    public UnidadOperativa(String ID,String modulo,TipoAtmosfera atmosfera) {
        this.ID = ID;
        this.modulo = modulo;
        this.atmosfera = atmosfera;
        
    }
    public abstract void reabastecerse();
    public abstract void mantenerCondicionesAtmosfericas();
    public abstract void replicarse();
    
    
    @Override
    public boolean equals(Object o) {
        if (o == null || !(o instanceof UnidadOperativa u)) 
            {  return false;  }

        return this.ID.equals(u.ID);
    }
    @Override
    public int hashCode(){
        return Objects.hash(ID);
    }
    
    
    @Override
    public String toString(){
        StringBuilder cadena = new StringBuilder();
        
        cadena.append("\nUnidad operativa: " +getClassName() );
        cadena.append("ID: " + ID + "\n");
        cadena.append("Modulo: " + modulo + "\n");
        cadena.append("Tipo de atmosfera: " + atmosfera + "\n");
        
        return cadena.toString();
        
    }
    protected String getClassName(){
        return this.getClass().getSimpleName(); 
    }

    public TipoAtmosfera getAtmosfera() {
        return atmosfera;
    }
    public void cumplirTodasLasFuncionesBase(){
        System.out.println("\nTipo: " + getClassName() + "\n");
        reabastecerse();
        mantenerCondicionesAtmosfericas();
        replicarse();
        
    }
    
}
