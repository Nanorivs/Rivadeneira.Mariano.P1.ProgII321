package paquete;

public interface Desplazable {
    void moverUnidad();
}
