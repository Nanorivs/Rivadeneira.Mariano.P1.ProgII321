package paquete;

import java.util.ArrayList;
import java.util.List;

public class BaseEspacial {
    private List<UnidadOperativa> unidadesOperativas;
    private String nombre;
    
    public BaseEspacial(String nombre){
        this.nombre = nombre;
        unidadesOperativas = new ArrayList<>();
    }
    public void agregarUnidadOperativa(UnidadOperativa unidad) throws IdRepetidoException {
        validarUnidad(unidad);
        unidadesOperativas.add(unidad);
    }
    
    private void validarUnidad(UnidadOperativa nuevaUnidad)throws IdRepetidoException{
        
        for(UnidadOperativa unidad: unidadesOperativas){
            if(unidad.equals(nuevaUnidad)){
                throw new IdRepetidoException();
            }
        }
    }
    
    
    public void mostrarUnidades(){
        
        for(UnidadOperativa unidad: unidadesOperativas){
            System.out.println(unidad);
        }
    }
    
    public void moverUnidades(){
        
    for(UnidadOperativa unidad: unidadesOperativas){
            if(unidad instanceof Desplazable){
                ((Desplazable) unidad).moverUnidad();
            }else{
                System.out.println(unidad.getClass() + " no puede moverse\n");
            }
        }
    
    }
    public void realizarFuncionesBase(){
        
        for(UnidadOperativa unidad: unidadesOperativas){
            unidad.cumplirTodasLasFuncionesBase();
        }
    
    }
    public void filtrarPorTipoAtmosfera(TipoAtmosfera tipo){
        System.out.println("Unidades segun: " + tipo.name());
        
        for(UnidadOperativa unidad: unidadesOperativas){
            if(unidad.getAtmosfera() == tipo){
                System.out.println(unidad);
            }
           
            }
        }
        
    
    
    }
    
    

