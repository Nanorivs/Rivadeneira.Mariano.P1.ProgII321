
package paquete;

public class Experimento extends UnidadOperativa{
    private final int horasDuracionIdeal;

    public Experimento(String ID, String modulo, TipoAtmosfera atmosfera,int horasDuracionIdeal) {
        super(ID, modulo, atmosfera);
        this.horasDuracionIdeal = horasDuracionIdeal;
    }

    @Override
    public void reabastecerse() {
        System.out.println("Los elementos claves del " + getClassName() + " fueron restituidos");
    }

    @Override
    public void mantenerCondicionesAtmosfericas() {
        System.out.println("Las condiciones atmosfericas del " + getClassName() + " son idoneas para experimentar");
    }

    @Override
    public void replicarse() {
        System.out.println("Ante escenarios fallidos, se ha replicado el "+getClassName());
    }
    @Override 
    public String toString(){   
        return super.toString() + "Duracion ideal: " + horasDuracionIdeal + " hs" ;
        
    }
    
}
