package paquete;

public class Main {

    public static void main(String[] args) {
        BaseEspacial base = new BaseEspacial("Space X");
        
        
        try{
            Astronauta a1 = new Astronauta("NDF124","QUARK",TipoAtmosfera.PRESURIZADA,3.5);
            Astronauta a2 = new Astronauta("OIN531","GAIA",TipoAtmosfera.VACIO,9);
            
            Robot r1 = new Robot("HCB752","EXPER",TipoAtmosfera.VACIO,8);
            Robot r2 = new Robot("MOP415","NAUTIC",TipoAtmosfera.PRESURIZADA,15);
            
            Experimento e1 = new Experimento("MPO123","NAVI",TipoAtmosfera.PRESURIZADA,3);
            Experimento e2 = new Experimento("NKQ666","LOCKIN",TipoAtmosfera.VACIO,7);
            
            base.agregarUnidadOperativa(a1);
            base.agregarUnidadOperativa(a2);
            base.agregarUnidadOperativa(r1);
            base.agregarUnidadOperativa(r2);
            base.agregarUnidadOperativa(e1);
            base.agregarUnidadOperativa(e2);

            base.filtrarPorTipoAtmosfera(TipoAtmosfera.VACIO);
            base.mostrarUnidades();
            base.realizarFuncionesBase();
            
        }catch(Exception e){
        
            System.out.println(e.getMessage());
        }
        
        
    }
    
}
