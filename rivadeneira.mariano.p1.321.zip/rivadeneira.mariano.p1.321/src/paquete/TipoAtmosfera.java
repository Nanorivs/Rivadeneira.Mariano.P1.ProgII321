package paquete;

public enum TipoAtmosfera {
    PRESURIZADA,
    VACIO
}
